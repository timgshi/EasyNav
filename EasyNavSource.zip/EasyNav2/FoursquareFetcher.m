//
//  FoursquareFetcher.m
//  EasyNav2
//
//  Created by Tim Shi on 8/11/11.
//  Copyright 2011 www.timshi.com. All rights reserved.
//

#import "FoursquareFetcher.h"
#import <MapKit/MapKit.h>

#define FoursquareID @"4L5YY03AJUODNELYB1LATCMUBDAMJGE4MO2JKTTFCKMRYSEP"
#define FoursquareSecret @"3FNFFJMYWR4A4OPKJUSSR2LIA0R5ZGOYLDB55CJSLRQASRUB"


@implementation FoursquareFetcher

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }

    return self;
}

+ (void)foursqureVenuesForQuery:(NSString *)query location:(CLLocation *)currentLocation completionBlock:(void (^)(NSArray *venues))block
{
    //dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        NSString *requestString = [NSString stringWithFormat:@"https://api.foursquare.com/v2/venues/search?ll=%f,%f&query=%@&client_id=%@&client_secret=%@&v=20110808", currentLocation.coordinate.latitude, currentLocation.coordinate.longitude, query, FoursquareID, FoursquareSecret];
        requestString = [requestString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *requestURL = [NSURL URLWithString:requestString];
        NSString *response = [NSString stringWithContentsOfURL:requestURL encoding:NSUTF8StringEncoding error:nil];
    //NSData *data = [NSJSONSerialization dataWithJSONObject:response options:0 error:nil];
    const char *utfstring = [response UTF8String];
    NSData *data = [NSData dataWithBytes:utfstring length:strlen(utfstring)];
    id responseDict = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    //NSLog(@"DICTIONARY: %@", [responseDict description]);
    NSLog(@"Class: %@", [responseDict class]);
    //NSLog(@"KEYS: %@", [responseDict allKeys]);
    //block([responseDict objectForKey:@"venues"]);
   // }
   // });
    NSDictionary *dict = (NSDictionary *)responseDict;
    NSLog(@"Keys: %@", [dict allKeys]);
    block([[dict objectForKey:@"response"] objectForKey:@"venues"]);
}

- (void)test
{  

}

@end
